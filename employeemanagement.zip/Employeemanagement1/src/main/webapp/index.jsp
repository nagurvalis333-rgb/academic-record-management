<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head><title>Employee Registration</title></head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<body>
<h2>Register Employee</h2>
<% if (request.getAttribute("error") != null) { %>
   <div style="color:red"><%= request.getAttribute("error") %></div>
<% } %>
<form action="EmployeeController" method="post">
  <input type="hidden" name="action" value="register" />
  Name: <input type="text" name="name" required/><br/>
  Email: <input type="email" name="email" required/><br/>
  Department: <input type="text" name="department" required/><br/>
  Salary: <input type="number" name="salary" step="0.01" required/><br/>
  Password: <input type="password" name="password" required/><br/>
  <button type="submit">Register</button>
</form>

<p><a href="login.jsp">Already registered? Login here</a></p>
</body>
</html>
