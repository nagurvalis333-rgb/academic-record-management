<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.model.Employee" %>
<!DOCTYPE html>
<html>
<head><title>Edit Employee</title></head>
<body>
<% Employee e = (Employee) request.getAttribute("employee");
   if (e == null) { response.sendRedirect("EmployeeController?action=view"); return; } %>
<h2>Edit Employee</h2>
<form action="EmployeeController" method="post">
  <input type="hidden" name="action" value="edit"/>
  <input type="hidden" name="id" value="<%= e.getId() %>"/>
  Name: <input type="text" name="name" value="<%= e.getName() %>" required/><br/>
  Email: <input type="email" name="email" value="<%= e.getEmail() %>" required/><br/>
  Department: <input type="text" name="department" value="<%= e.getDepartment() %>" required/><br/>
  Salary: <input type="number" name="salary" value="<%= e.getSalary() %>" step="0.01" required/><br/>
  <button type="submit">Update</button>
</form>
<p><a href="EmployeeController?action=view">Back to list</a></p>
</body>
</html>
