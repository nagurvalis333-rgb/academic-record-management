<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.*" %>
<!DOCTYPE html>
<html>
<head><title>Home</title></head>
<body>
<% String email = (String) session.getAttribute("email");
   if (email == null) { response.sendRedirect("login.jsp"); return; } %>
<h2>Welcome, <%= email %></h2>
<p><a href="EmployeeController?action=view">View Employees</a></p>
<p><a href="index.jsp">Register Employee</a></p>
</body>
</html>
