<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.*, com.model.Employee" %>
<!DOCTYPE html>
<html>
<head><title>Employees</title></head>
<body>
<h2>Employees</h2>
<table border="1">
<tr><th>ID</th><th>Name</th><th>Email</th><th>Dept</th><th>Salary</th><th>Action</th></tr>
<% List<Employee> list = (List<Employee>) request.getAttribute("employees");
   if (list != null) {
     for (Employee e : list) { %>
<tr>
  <td><%= e.getId() %></td>
  <td><%= e.getName() %></td>
  <td><%= e.getEmail() %></td>
  <td><%= e.getDepartment() %></td>
  <td><%= e.getSalary() %></td>
  <td>
    <a href="EmployeeController?action=editForm&id=<%= e.getId() %>">Edit</a> |
    <form action="EmployeeController" method="post" style="display:inline">
      <input type="hidden" name="action" value="delete"/>
      <input type="hidden" name="id" value="<%= e.getId() %>"/>
      <button type="submit">Delete</button>
    </form>
  </td>
</tr>
<%   }
   } else { %>
<tr><td colspan="6">No employees found</td></tr>
<% } %>
</table>
<p><a href="home.jsp">Back</a></p>
</body>
</html>
