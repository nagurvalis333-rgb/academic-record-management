<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<body>
<h2>Login</h2>
<% if (request.getAttribute("error") != null) { %>
   <div style="color:red"><%= request.getAttribute("error") %></div>
<% } %>
<form action="LoginController" method="post">
  Email: <input type="email" name="email" required/><br/>
  Password: <input type="password" name="password" required/><br/>
  <button type="submit">Login</button>
</form>
<p><a href="index.jsp">Register new employee</a></p>
</body>
</html>
