package com.utility; // keep your package

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/employeedb?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "root";

    public static Connection getConnection() throws SQLException {
        try {
            // force driver registration (helps when container classloading doesn't auto-register)
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            // helpful error if the jar is missing at runtime
            throw new SQLException("MySQL JDBC driver not found in classpath", e);
        }
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
