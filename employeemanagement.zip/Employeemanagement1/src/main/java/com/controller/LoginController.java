package com.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.dao.EmployeeDAO;
import com.model.LoginModel;

import java.io.IOException;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        LoginModel lm = new LoginModel();
        lm.setEmail(email); lm.setPassword(password);

        EmployeeDAO dao = new EmployeeDAO();
        String status = dao.validateLogin(lm);

        if ("success".equals(status)) {
            HttpSession session = request.getSession();
            session.setAttribute("email", email);
            response.sendRedirect("home.jsp");
        } else {
            request.setAttribute("error", "Invalid credentials");
            RequestDispatcher rd = request.getRequestDispatcher("login.jsp"); rd.forward(request, response);
        }
    }
}
