package com.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.dao.EmployeeDAO;
import com.model.Employee;
import com.utility.PasswordUtil;

import java.io.IOException;
import java.util.List;

@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action"); // register, edit, delete
        EmployeeDAO dao = new EmployeeDAO();

        if ("register".equals(action)) {
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String dept = request.getParameter("department");
            String salaryStr = request.getParameter("salary");
            String password = request.getParameter("password");

            double salary = 0;
            try { salary = Double.parseDouble(salaryStr); } catch (Exception e) {}

            Employee e = new Employee();
            e.setName(name); e.setEmail(email); e.setDepartment(dept); e.setSalary(salary);
            e.setPasswordHash(PasswordUtil.hash(password));

            String status = dao.insertEmployee(e);
            if ("success".equals(status)) {
                response.sendRedirect("login.jsp");
            } else {
                request.setAttribute("error", "Registration failed");
                RequestDispatcher rd = request.getRequestDispatcher("index.jsp"); rd.forward(request, response);
            }

        } else if ("edit".equals(action)) {
            // Update employee record
            try {
                int id = Integer.parseInt(request.getParameter("id"));
                String name = request.getParameter("name");
                String email = request.getParameter("email");
                String dept = request.getParameter("department");
                double salary = Double.parseDouble(request.getParameter("salary"));

                Employee e = new Employee();
                e.setId(id); e.setName(name); e.setEmail(email); e.setDepartment(dept); e.setSalary(salary);

                String status = dao.updateEmployee(e);
                // Redirect to controller view to reload fresh list
                response.sendRedirect("EmployeeController?action=view");
            } catch (Exception ex) {
                ex.printStackTrace();
                request.setAttribute("error", "Update failed");
                RequestDispatcher rd = request.getRequestDispatcher("editEmployee.jsp"); rd.forward(request, response);
            }

        } else if ("delete".equals(action)) {
            try {
                int id = Integer.parseInt(request.getParameter("id"));
                dao.deleteEmployee(id);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            // After delete, redirect to controller view to refresh list
            response.sendRedirect("EmployeeController?action=view");

        } else {
            // Unknown action: go to index
            response.sendRedirect("index.jsp");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action"); // view, editForm
        EmployeeDAO dao = new EmployeeDAO();

        if ("view".equals(action)) {
            List<Employee> list = dao.getAllEmployees();
            request.setAttribute("employees", list);
            RequestDispatcher rd = request.getRequestDispatcher("viewEmployees.jsp");
            rd.forward(request, response);

        } else if ("editForm".equals(action)) {
            try {
                int id = Integer.parseInt(request.getParameter("id"));
                request.setAttribute("employee", dao.getEmployeeById(id));
                RequestDispatcher rd = request.getRequestDispatcher("editEmployee.jsp");
                rd.forward(request, response);
            } catch (Exception ex) {
                ex.printStackTrace();
                response.sendRedirect("EmployeeController?action=view");
            }
        } else {
            // default: show registration page
            response.sendRedirect("index.jsp");
        }
    }
}
