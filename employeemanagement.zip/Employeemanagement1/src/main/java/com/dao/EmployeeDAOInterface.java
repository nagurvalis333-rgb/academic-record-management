package com.dao;

import java.util.List;
import com.model.Employee;
import com.model.LoginModel;

public interface EmployeeDAOInterface {
    String insertEmployee(Employee e);
    List<Employee> getAllEmployees();
    Employee getEmployeeById(int id);
    String updateEmployee(Employee e);
    String deleteEmployee(int id);
    String validateLogin(LoginModel lm);
}
