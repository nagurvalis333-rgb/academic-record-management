package com.dao;

import java.sql.*;
import java.util.*;
import com.model.Employee;
import com.model.LoginModel;
import com.utility.DBConnection;
import com.utility.PasswordUtil;

public class EmployeeDAO implements EmployeeDAOInterface {

    @Override
    public String insertEmployee(Employee e) {
        String status = "failure";
        String sql = "INSERT INTO employees(name,email,department,salary,password_hash) VALUES(?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getName());
            ps.setString(2, e.getEmail());
            ps.setString(3, e.getDepartment());
            ps.setDouble(4, e.getSalary());
            ps.setString(5, e.getPasswordHash());
            int n = ps.executeUpdate();
            if (n > 0) status = "success";
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return status;
    }

    @Override
    public List<Employee> getAllEmployees() {
        List<Employee> list = new ArrayList<>();
        String sql = "SELECT id,name,email,department,salary FROM employees";
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Employee e = new Employee();
                e.setId(rs.getInt("id"));
                e.setName(rs.getString("name"));
                e.setEmail(rs.getString("email"));
                e.setDepartment(rs.getString("department"));
                e.setSalary(rs.getDouble("salary"));
                list.add(e);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    @Override
    public Employee getEmployeeById(int id) {
        Employee e = null;
        String sql = "SELECT id,name,email,department,salary FROM employees WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    e = new Employee();
                    e.setId(rs.getInt("id"));
                    e.setName(rs.getString("name"));
                    e.setEmail(rs.getString("email"));
                    e.setDepartment(rs.getString("department"));
                    e.setSalary(rs.getDouble("salary"));
                }
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        return e;
    }

    @Override
    public String updateEmployee(Employee e) {
        String status = "failure";
        String sql = "UPDATE employees SET name=?, email=?, department=?, salary=? WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getName());
            ps.setString(2, e.getEmail());
            ps.setString(3, e.getDepartment());
            ps.setDouble(4, e.getSalary());
            ps.setInt(5, e.getId());
            int n = ps.executeUpdate();
            if (n > 0) status = "success";
        } catch (SQLException ex) { ex.printStackTrace(); }
        return status;
    }

    @Override
    public String deleteEmployee(int id) {
        String status = "failure";
        String sql = "DELETE FROM employees WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            int n = ps.executeUpdate();
            if (n > 0) status = "success";
        } catch (SQLException ex) { ex.printStackTrace(); }
        return status;
    }

    @Override
    public String validateLogin(LoginModel lm) {
        String status = "failure";
        String sql = "SELECT password_hash FROM employees WHERE email=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, lm.getEmail());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String storedHash = rs.getString("password_hash");
                    if (PasswordUtil.matches(lm.getPassword(), storedHash)) {
                        status = "success";
                    }
                }
            }
        } catch (SQLException ex) { ex.printStackTrace(); }
        return status;
    }
}
